
{-- snippet ternary --}
data Ternary
    = Yes
    | No
    | Unknown
    deriving (Eq,Show)
{-- /snippet ternary --}
