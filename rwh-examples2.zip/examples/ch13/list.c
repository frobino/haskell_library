#include <stdio.h>

/** snippet list */
struct list {
    struct node *head, *tail;
};
/** /snippet list */
