{-- snippet import1 --}
import qualified Data.Sequence as Seq
{-- /snippet import1 --}

{-- snippet import2 --}
import Data.Sequence ((><), (<|), (|>))
{-- /snippet import2 --}

{-- snippet import3 --}
import qualified Data.Foldable as Foldable
{-- /snippet import3 --}
