{-- snippet all --}
module Main where

import qualified PodMainGUI

main = PodMainGUI.main "podresources.glade"
{-- /snippet all --}
