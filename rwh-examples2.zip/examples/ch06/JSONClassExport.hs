{-- snippet module --}
module JSONClass
    (
      JAry(..)
    ) where
{-- /snippet module --}

{-- snippet abstract --}
module JSONClass
    (
      JAry(fromJAry)
    , jary
    ) where
{-- /snippet abstract --}
