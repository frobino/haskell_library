{-- snippet all --}
data Color = Red | Green | Blue
     deriving (Read, Show, Eq, Ord)
{-- /snippet all --}

