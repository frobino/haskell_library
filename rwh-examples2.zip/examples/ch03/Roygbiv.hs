{-- snippet Roygbiv --}

data Roygbiv = Red
             | Orange
             | Yellow
             | Green
             | Blue
             | Indigo
             | Violet
               deriving (Eq, Show)

{-- /snippet Roygbiv --}
