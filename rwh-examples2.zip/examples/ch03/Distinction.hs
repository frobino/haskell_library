{-- snippet tuples --}
a = ("Porpoise", "Grey")
b = ("Table", "Oak")
{-- /snippet tuples --}

{-- snippet data --}
data Cetacean = Cetacean String String
data Furniture = Furniture String String

c = Cetacean "Porpoise" "Grey"
d = Furniture "Table" "Oak"
{-- /snippet data --}
