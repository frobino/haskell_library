{-- snippet itemName --}
itemName = "Weighted Companion Cube"
{-- /snippet itemName --}
