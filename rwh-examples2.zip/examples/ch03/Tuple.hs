{-- snippet third --}
third (a, b, c) = c
{-- /snippet third --}

{-- snippet complicated --}
complicated (True, a, x:xs, 5) = (a, xs)
{-- /snippet complicated --}
