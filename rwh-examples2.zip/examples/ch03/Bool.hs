import Prelude hiding (Bool(..))

{-- snippet Bool --}
data Bool = False | True
{-- /snippet Bool --}
