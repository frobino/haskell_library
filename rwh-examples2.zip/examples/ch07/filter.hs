{-- snippet all --}
main = interact (unlines . filter (elem 'a') . lines)
{-- /snippet all --}

