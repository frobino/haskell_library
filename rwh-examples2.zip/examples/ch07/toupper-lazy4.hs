{-- snippet all --}
import Data.Char(toUpper)

main = interact (map toUpper)
{-- /snippet all --}

