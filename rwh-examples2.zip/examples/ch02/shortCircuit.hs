{-- snippet newOr --}
newOr a b = if a then a else b
{-- /snippet newOr --}
