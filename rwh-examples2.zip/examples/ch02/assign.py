## snippet assign

x = 10
x = 11
# value of x is now 11
print x

## /snippet assign
