{-- snippet odd --}
isOdd n = mod n 2 == 1
{-- /snippet odd --}
