{-- snippet type --}
take :: Int -> ([a] -> [a])
{-- /snippet type --}
take = undefined
