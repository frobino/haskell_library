/** snippet type **/
double sin(double x);
/** /snippet type **/
