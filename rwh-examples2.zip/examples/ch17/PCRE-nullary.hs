{-# LANGUAGE EmptyDataDecls #-}

module T where

{-- snippet nullary --}
data PCRE
{-- /snippet nullary --}
