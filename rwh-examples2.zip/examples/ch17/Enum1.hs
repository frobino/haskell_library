{-- snippet cpp --}
{-# LANGUAGE CPP #-}

#define N 16

main = print [ 1 .. N ]
{-- /snippet cpp --}
