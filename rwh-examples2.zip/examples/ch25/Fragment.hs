{-- snippet fragment --}
mean :: [Double] -> Double
mean xs = sum xs / fromIntegral (length xs)
{-- /snippet fragment --}
